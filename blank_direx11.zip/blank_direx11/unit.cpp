#include "pch.h"
#include "unit.h"

#include "Game.h"
#include <fstream>

#include "WICTextureLoader.h"

unit::unit()
{
}

void unit::Initiate()
{
	
	T = 0.0;

	CD3D11_BUFFER_DESC constantBufferDesc(sizeof(my_model), D3D11_BIND_CONSTANT_BUFFER);
	dev->CreateBuffer(
		&constantBufferDesc,
		nullptr,
		&m_constantBuffer
	);


}

void unit::Update(XMFLOAT3 input)
{
	
	



//	XMMatrixTranslation(1.0f, 0.1f, 0.1f) 

	FXMVECTOR A = XMLoadFloat3(&pos);

	XMVECTOR B = XMVectorSet(0.1f, 0.1f, 0.1f, 0.0f);

	XMVECTOR C = A + B;

 // 0.5f, 0.5f, 0.5f
	XMMATRIX move = XMMatrixTranslationFromVector(FXMVECTOR(A));

    XMStoreFloat4x4(&my_model.model, XMMatrixTranspose(XMMatrixTranslation())));

	T += 0.11;

	XMStoreFloat3(&pos,A);

}

void unit::Render()
{

	devcon->PSSetSamplers(0, 1, my_sampleState.GetAddressOf());

	devcon->PSSetShaderResources(0, 1, my_texture.GetAddressOf());

	// Prepare the constant buffer to send it to the graphics device.
	devcon->UpdateSubresource1(
		m_constantBuffer.Get(),
		0,
		NULL,
		&my_model,
		0,
		0,
		0
	);


	// set the vertex buffer
	UINT stride = sizeof(VERTEX);
	UINT offset = 0;
	devcon->IASetVertexBuffers(0, 1, vertexbuffer.GetAddressOf(), &stride, &offset);

	// Send the constant buffer to the graphics device.
	devcon->VSSetConstantBuffers1(
		0,
		1,
		m_constantBuffer.GetAddressOf(),
		nullptr,
		nullptr
	);

	// set the primitive topology
	devcon->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);


	// draw 3 vertices, starting from vertex 0
	devcon->Draw(6, 0);




}


// this function loads and initializes all graphics data
void unit::InitGraphics()
{


	VERTEX OurVertices[] =
	{
		{ XMFLOAT3(-0.04f, 0.06f, 0.0f), XMFLOAT2(0.0f, 0.0f) },
		{ XMFLOAT3(0.04f,-0.06f, 0.0f), XMFLOAT2(1.0f, 1.0f) },
		{ XMFLOAT3(-0.04f,-0.06f, 0.0f), XMFLOAT2(0.0f, 1.0f) },

		{ XMFLOAT3(-0.04f, 0.06f, 0.0f), XMFLOAT2(0.0f, 0.0f) },
		{ XMFLOAT3(0.04f, 0.06f, 0.0f), XMFLOAT2(1.0f, 0.0f) },
		{ XMFLOAT3(0.04f, -0.06f, 0.0f), XMFLOAT2(1.0f, 1.0f) },

	};

	// create the vertex buffer
	D3D11_BUFFER_DESC bd = { 0 };
	bd.ByteWidth = sizeof(VERTEX) * ARRAYSIZE(OurVertices);
	bd.BindFlags = D3D11_BIND_VERTEX_BUFFER;

	D3D11_SUBRESOURCE_DATA srd = { OurVertices, 0, 0 };

	dev->CreateBuffer(&bd, &srd, &vertexbuffer);



	///////////////**************new**************////////////////////



	D3D11_TEXTURE2D_DESC desc;
	desc.Width = 256;
	desc.Height = 256;
	desc.MipLevels = desc.ArraySize = 1;
	desc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
	desc.SampleDesc.Count = 1;
	desc.Usage = D3D11_USAGE_DYNAMIC;
	desc.BindFlags = D3D11_BIND_SHADER_RESOURCE;
	desc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
	desc.MiscFlags = 0;

	ID3D11Texture2D *pTexture = NULL;

	dev->CreateTexture2D(
		&desc,
		NULL,
		&pTexture);



	CreateWICTextureFromFile
	(
		dev.Get(),
		devcon.Get(),
		L"texture\\load.png",
		&r_texture,
		&my_texture,
		0
	);

	// Describe the Sample State
	D3D11_SAMPLER_DESC sampDesc;
	ZeroMemory(&sampDesc, sizeof(sampDesc));
	sampDesc.Filter = D3D11_FILTER_MIN_MAG_MIP_LINEAR;
	sampDesc.AddressU = D3D11_TEXTURE_ADDRESS_WRAP;
	sampDesc.AddressV = D3D11_TEXTURE_ADDRESS_WRAP;
	sampDesc.AddressW = D3D11_TEXTURE_ADDRESS_WRAP;
	sampDesc.ComparisonFunc = D3D11_COMPARISON_NEVER;
	sampDesc.MinLOD = 0;
	sampDesc.MaxLOD = D3D11_FLOAT32_MAX;

	//Create the Sample State
	dev->CreateSamplerState(&sampDesc, &my_sampleState);
	///////////////**************new**************////////////////////




}
